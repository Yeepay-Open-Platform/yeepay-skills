const config = {
  "wxb92a409f35b31843": {
    "appid": "wxb92a409f35b31843",
    "industry": "电商",
    "type": "小程序",
    "app_name": "YP服务管理",
    "company": "易宝支付有限公司",
    "email": "xx@xx.com",
    "original_id": "gh_xx",
    "cloud_env": "cloud1-xx",
    "manager": "xx"
  },
}

module.exports = config;

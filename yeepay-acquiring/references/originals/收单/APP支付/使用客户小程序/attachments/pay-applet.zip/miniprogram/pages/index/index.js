// pages/index/index.js
const app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  jump: function (e) {
    var tag = e.currentTarget.dataset.flag;
    wx.navigateTo({
      url: "/packageOrder/order/index",
    });
  }
});

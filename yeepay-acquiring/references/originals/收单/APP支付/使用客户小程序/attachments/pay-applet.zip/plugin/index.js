module.exports = {
  data: {
    fee: 1,             // 支付金额，单位为分
    paymentArgs: '', // 将传递到功能页函数的自定义参数
    currencyType: 'CNY', // 货币符号，页面显示货币简写 US$ 
    version: 'release', // 上线时，version 应改为 "release"，并确保插件所有者小程序已经发布
  },
  authCode: '',
  qaList: [
    "10040020578",
    "10040040287",
    "10080020652",
    "10028240235",
    "10080029837",
  ],
  orderInfo: {
    state: "",
    customerNo: "", // 商户编号
    customerRequestNo: "", // 商户交易订单号
    orderAmount: "", // 订单金额
    goodsName: "", // 商品名称(传参过来，不支持中文)
    authCode: "",
  },
  sayHello: function () {
    console.log("Hello plugin!");
  },
  login: function () {
    wx.pluginLogin({
      success: (res) => {
        if (res.code) {
          this.authCode = res.code;
          console.log("res.code", res.code);
          this.confirmPay();
        } else {
          wx.showToast({
            title: `登录失败！${res.errMsg}`,
            icon: "none",
            duration: 3000,
          });
        }
      },
      fail: (res) => {},
      complete: (res) => {},
    });
  },
  confirmPay: function(params) {
    let url = 'https://qr.yeepay.com/wrap/pay'
    if(this.qaList.includes(params.customerNo)) {
      url = 'https://aggwrapqa.yeepay.com/aggregation-pay-server/qr/wrap/pay'
    }
    wx.request({
      url,
      method: 'POST',
      header: {
        'content-type': 'application/json'
      },
      data: {
        state: params.state,
        authCode: this.authCode,
      },
      success: res => {
        if (res.data.code == '00000') {
          this.data.uniqueOrderNo = res.data.uniqueOrderNo
          this.requestPayment(JSON.parse(res.data.prePayTn));
        } else {
          wx.showToast({
            title: `${res.data.message}(${this.data.orderInfo.state})`,
            icon: 'none',
            duration: 3000
          });
        }
      },
      fail: (err) => {
        wx.showToast({
          title: JSON.stringify(err),
          icon: 'none',
          duration: 5000
        });
      },
      complete: () => {
        this.setData({
          loading: false,
          disabled: false
        })
      }
    });
  },
  requestPayment: function(params) {
    wx.requestPluginPayment({
      ...params,
      success(r) {
        console.log('requestPluginPayment:sucess ====', r)
      },
      fail(e) {
        console.error('requestPluginPayment:fail ====', e)
      }
    })
  },
  yeepayPlugin: function (params) {
    let logger = null
    if (wx.getRealtimeLogManager) {
      const logManager = wx.getRealtimeLogManager()
      let state = params.paymentArgs && params.paymentArgs.state ? params.paymentArgs.state : ''
      logger = logManager.tag(state)
    }
    logger && logger.info('yeepayPlugin:入参====', params)
    console.log("yeepayPlugin=====",params);
    return new Promise ((resolve,reject)=>{
      try {
        wx.requestPluginPayment({
          ...params,
          version: "release",
          success(res) {
            logger && logger.info('requestPluginPayment:sucess', res)
            console.log('requestPluginPayment:sucess ====', res)
            resolve(res)
          },
          fail(error) {
            logger && logger.error('wx.requestPluginPayment 调用失败:', error)
            console.error('requestPluginPayment:fail ====', error)
            reject(error)
          }
        })
      } catch (error) {
        logger && logger.error('wx.requestPluginPayment error:', error)
        try {
          const res = wx.getSystemInfoSync()
          logger && logger.error('requestPluginPayment error 系统信息===:', res)
          console.log('requestPluginPayment error 系统信息===', res)
        } catch (e) {
          // Do something when catch error
        }
        console.error('调用requestPluginPayment: error ====', error)
      }
    })
  },
};

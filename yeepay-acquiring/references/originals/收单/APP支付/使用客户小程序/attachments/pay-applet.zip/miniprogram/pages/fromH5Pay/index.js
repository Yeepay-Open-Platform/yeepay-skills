import Toast from '../../components/@vant/toast/toast';
const app = getApp()

import tool from "../../utils/util.js";
Page({
  data: {
    payResult: 'nomal',
    loading: false,
    disabled: false,
    showSuccessPopup: false,
    payInfo: {}, // 支付订单信息
    merchantAppId: null,
		userId: '',
    orderInfo: {
      state: '',
			customerNo: '',   // 商户编号
			customerRequestNo: '',   // 商户交易订单号
      orderAmount: '',  // 订单金额
      goodsName: '', // 商品名称(传参过来，不支持中文)
    },

    realtimeLogger: null,
    scene: 1065,
    loadingToast: null
  },
  onLoad(option) {
    
    const referrerInfo =  app.globalData.referrerInfo
    if (referrerInfo && option.launchSource === 'MINI_PROGRAM') {
      if(referrerInfo.appId) {
        this.data.merchantAppId = referrerInfo.appId
      } else {
        console.log("未获取到小程序id")
      }
    }

    const scene = wx.getLaunchOptionsSync().scene || 1065;
    this.data.loadingToast = Toast.loading({
      mask:true,
      message: '加载中...',
      forbidClick: true,
      duration: 0
    });
    this.setData({
      loading: true,
      disabled: true,
    });
		if (wx.canIUse("getRealtimeLogManager")) {
      const logger = wx.getRealtimeLogManager();
      this.setData({
        realtimeLogger: logger,
      });

      this.data.realtimeLogger.info("fromH5Pay: 页面 初始化 ===",option);
    }
    console.log(scene, 'scene');
		// 设置跳转携带的参数
    this.setData({
      orderInfo: {
        state: option.state,
				customerNo: option.customerNo,
				customerRequestNo: option.customerRequestNo,
				orderAmount: Number(option.orderAmount).toFixed(2),
        goodsName: decodeURIComponent(option.goodsName),
        scene
			}
		})
		// 通过云函数获取openid
		this.onGetOpenid()
	},
	onGetOpenid: function () {
			this.data.realtimeLogger && this.data.realtimeLogger.info(
        "fromH5Pay: 获取 openid ==="
      );
			wx.cloud.init({
				traceUser: true,
			})
			// 调用云函数
			wx.cloud.callFunction({
				name: 'login',
				data: {},
				success: res => {
          this.setData({
						userId :res.result.openid
					})
					this.data.realtimeLogger && this.data.realtimeLogger.info(
            `fromH5Pay: 用户 openid ${res.result.openid} ===`,
            res.result.openid
          );
          wx.hideLoading()
          this.confirmPay()
				},
        fail: err => {
          this.data.realtimeLogger && this.data.realtimeLogger.error(
            "wx.cloud login error ===",
            err
          );
					wx.hideLoading()
				}
			})
  },
	confirmPay: tool.debounce(function () {
			this.data.realtimeLogger && this.data.realtimeLogger.info(
        `fromH5Pay[confirmPay]: 调用 API /qr/wrap/pay  ===`
      );
      this.setData({
        loading: true,
        disabled: true
      })
      let url = 'https://qr.yeepay.com/wrap/pay'
      if(this.data.orderInfo.customerNo === '10080019702') {
        url = 'https://aggwrapqa.yeepay.com/aggregation-pay-server/qr/wrap/pay'
      }
			//获取微信支付所需要的参数, 链接需替换
			wx.request({
				url,
				method: 'POST',
				header: {
					'content-type': 'application/json'
				},
				data: {
					state: this.data.orderInfo.state,
					userId: this.data.userId,
          merchantAppId: this.data.merchantAppId,
				},
				success: res => {
          const state = this.data.orderInfo.state
					if (res.data.code == '00000') {
						this.data.realtimeLogger && this.data.realtimeLogger.info(
              `fromH5Pay[confirmPay]: 获取 订单信息成功  ===`,
              res.data
            );
            this.requestPayment(JSON.parse(res.data.prePayTn));
					} else {
						this.data.realtimeLogger && this.data.realtimeLogger.warn(
              `fromH5Pay[confirmPay]: 订单信息获取失败 ===`,
              res.data
            );
						wx.showToast({
							title: `${res.data.message}(${state})`,
							icon: 'none',
							duration: 3000
						});
					}
				},
        fail: (err) => {
          this.data.realtimeLogger && this.data.realtimeLogger.error(
            "wx.request confirmPay fail ===",
            err
          );
					wx.showToast({
						title: `${err.errMsg}(${err.errno})`,
						icon: 'none',
						duration: 3000
					});
				},
        complete: () => {
          this.data.loadingToast.clear()
          this.setData({
            loading: false,
            disabled: false
          })
				}
			});
  }),
	requestPayment: function (data) {
			this.data.realtimeLogger && this.data.realtimeLogger.info(
        `fromH5Pay[requestPayment]:  唤起支付 ===`,
        data
      );
			wx.requestPayment({
        ...data,
        success: (res) => {
					// 完成支付跳转支付成功页
					this.data.realtimeLogger && this.data.realtimeLogger.info(
            `fromH5Pay[requestPayment]:  支付成功 ===`,
            res
          );
          let orderAmount = this.data.orderInfo.orderAmount
          let scene = this.data.scene
          setTimeout(function(){
            wx.reLaunch({
              url: `/pages/result/index?payResult=success&orderAmount=${orderAmount}&scene=${scene}`,
              success(res){
                console.log('reLaunch 成功', res)
              },
              fail(err){
                console.log('reLaunch 失败', err)
              }
            })
          },200)
        },
        fail: (err) => {
          this.data.realtimeLogger && this.data.realtimeLogger.error(
            `fromH5Pay[requestPayment]:  支付失败 ===`,
            err
          );
          this.setData({
            payResult: "payError",
          });
        },
      });
    },
	hideSuccessPopup: function () {
			this.data.realtimeLogger && this.data.realtimeLogger.info(
        `fromH5Pay[hideSuccessPopup]:  退出程序 ===`
      );
      this.setData({
        showSuccessPopup: false
      })
      wx.exitMiniProgram()
    }
})

const app = getApp();
Page({
  /**
   * 页面的初始数据
   */

  data: {
    list: [
      {
        goodname: "茶具套装",
        img: "https://img.yeepay.com/fe-resources/mini-app/img/product/product-1.jpeg",
        defaultNum: 239,
        num: 99,
        info1:
          "一只茶壶泡出一壶好茶,盖为天、托为地、碗为人,暗含天地人和之意。\n生活再简单,也要有诗意。",
        info2:
          "划线价格:商品的建议零售价,并非原价,仅供参考\n未划线价格:商品的实际价格,具体成交价格根据商品参加活动或试用优惠券、积分等情形会发生变化,最终以收银台结支付价格位准。",
        info3:
          "本商品根据实际库存,可能存在无法支付的情况;若库存不足,依然支付成功,将无法发货,请联系商家退款。",
        tags: [
          "户外旅行",
          "家用",
          "一壶四杯",
          "定制logo",
          "茶具套装便携包",
        ],
      },
      {
        goodname: "商务礼盒",
        img: "https://img.yeepay.com/fe-resources/mini-app/img/product/product-2.jpeg",
        defaultNum: 1288,
        num: 999,
        info1:
          "匠心智造,品质生活\n既是暖手宝,也是充电宝",
        info2:
          "划线价格:商品的建议零售价,并非原价,仅供参考\n未划线价格:商品的实际价格,具体成交价格根据商品参加活动或试用优惠券、积分等情形会发生变化,最终以收银台结支付价格位准。",
        info3:
          "本商品根据实际库存,可能存在无法支付的情况;若库存不足,依然支付成功,将无法发货,请联系商家退款。",
        tags: [
          "定制logo",
          "送客户员工",
          "伴手礼盒",
        ],
      },
      {
        goodname: "员工礼盒",
        img: "https://img.yeepay.com/fe-resources/mini-app/img/product/product-3.jpeg",
        defaultNum: 299,
        num: 219,
        info1:
          "百搭不挑,有容乃大\n心想事橙,好事橙双",
        info2:
          "划线价格:商品的建议零售价,并非原价,仅供参考\n未划线价格:商品的实际价格,具体成交价格根据商品参加活动或试用优惠券、积分等情形会发生变化,最终以收银台结支付价格位准。",
        info3:
          "本商品根据实际库存,可能存在无法支付的情况;若库存不足,依然支付成功,将无法发货,请联系商家退款。",
        tags: [
          "激励奖品",
          "年会礼品伴手礼",
        ],
      },
      {
        goodname: "文具礼盒",
        img: "https://img.yeepay.com/fe-resources/mini-app/img/product/product-4.jpeg",
        defaultNum: 688,
        num: 599,
        info1:
          "妙笔生辉,万卷诗书\n运筹帷幄之中,决胜千里之外",
        info2:
          "划线价格:商品的建议零售价,并非原价,仅供参考\n未划线价格:商品的实际价格,具体成交价格根据商品参加活动或试用优惠券、积分等情形会发生变化,最终以收银台结支付价格位准。",
        info3:
          "本商品根据实际库存,可能存在无法支付的情况;若库存不足,依然支付成功,将无法发货,请联系商家退款。",
        tags: [
          "商务本子定制",
          "可印logo",
          "高档A5伴手礼",
          "学生奖品",
          "会议纪念礼品",
          "加厚记事纪录本文创",
        ],
      },
    ],
    navigationSetting: {
      title: '分类',
      navBarHeight: app.globalData.navBarHeight,
      statusBarHeight: app.globalData.statusBarHeight,
      showBack: false,
    },
    height: app.globalData.navBarHeight + app.globalData.statusBarHeight,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(__wxConfig)
  },
  openDetail(e) {
    let { item } = e.currentTarget.dataset;
    console.log('dataset', e.currentTarget.dataset)
    wx.navigateTo({
      url: '/packageGoods/goods/detail?item='+ JSON.stringify(item)
    });
  },
});

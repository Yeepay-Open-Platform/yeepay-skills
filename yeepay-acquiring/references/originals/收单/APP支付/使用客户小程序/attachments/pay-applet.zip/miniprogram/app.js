// app.js
import { RELEASE_URI, DEVELOP_URI, TRIAL_URI } from './api/base'
const ENUM_API = {
  release: RELEASE_URI,
  develop: DEVELOP_URI,
  trial: TRIAL_URI,
}
App({
  onLaunch(options) {
    // 唤醒云函数
    wx.cloud.init({
      traceUser: true,
    });
    wx.hideHomeButton()
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: (res) => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      },
    });
    wx.onAppHide((res) => {
      // wx.exitMiniProgram()
      wx.redirectTo({
        url: "pages/home/index",
      });
    });

    const systemInfo = wx.getSystemInfoSync(); //获取系统信息
    const menuInfo = wx.getMenuButtonBoundingClientRect(); // 获取胶囊按钮的信息

    this.globalData.statusBarHeight = systemInfo.statusBarHeight; // 获取状态栏的高
    this.globalData.navBarHeight = (menuInfo.top - systemInfo.statusBarHeight) * 2 + menuInfo.height; // 计算出导航栏的高度

     wx.loadFontFace({
       family: "iconfont",
       source:
         'url("https://img.yeepay.com/fe-resources/mini-app/icon/iconfont.woff2")',
       success(res) {
         console.log("loadFontFace success = ", res.status);
       },
       fail: function (res) {
         console.log("loadFontFace fail = ", res.status);
       },
     });

    const getAccountInfoSync = wx.getAccountInfoSync()
    const envVersion = getAccountInfoSync.miniProgram?.envVersion
    const referrerInfo = options.referrerInfo

    this.globalData.envVersion = envVersion
    this.globalData.requestUrl = ENUM_API[envVersion]
    this.globalData.referrerInfo = referrerInfo;

  },

  onShow(options){
    const getAccountInfoSync = wx.getAccountInfoSync()
    const envVersion = getAccountInfoSync.miniProgram?.envVersion
    const referrerInfo = options.referrerInfo
    // console.log('onshow=====referrerInfo', referrerInfo)
    this.globalData.envVersion = envVersion
    this.globalData.requestUrl = ENUM_API[envVersion]
    this.globalData.referrerInfo = referrerInfo;
  },
  onHide(){
    wx.redirectTo({
      url: 'pages/index/index'
    })
    wx.exitMiniProgram()
  },
  globalData: {
    userInfo: null,
    navBarHeight: 0, // 导航栏高度
    statusBarHeight: 0, //状态栏高度
    envVersion: '', // 环境变量
    requestUrl: "https://qr.yeepay.com/wrap", // 域名
    referrerInfo: {}, // 来源小程序的参数
  },
});

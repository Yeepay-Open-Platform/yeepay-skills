var plugin = requirePlugin("yeepay-plugin");
const app = getApp();

Page({
  data: {
    appId: "wx3ab38c026e67f023",
    path: "/pages/fromAppPay/index?state=cdaccce8-e657-4fdd-8950-cb6763414565&customerNo=10040020578&goodsName=%E5%86%85%E6%B5%8B%E9%AA%8C%E8%AF%81%E5%95%86%E5%93%81%E5%90%8D%E7%A7%B0&customerRequestNo=orderId60565177&orderAmount=0.02&launchSource=MINI_PROGRAM",
    banner:
      "https://img.yeepay.com/fe-resources/projects/miniApp/yitongcheng/banner@2x.png",
    category:[
      {
        icon: "https://img.yeepay.com/fe-resources/projects/miniApp/yitongcheng/order_icon@2x.png",
        desc:"订单记录",
        flag: "order",
        url: ''
      },
      {
        icon: "https://img.yeepay.com/fe-resources/projects/miniApp/yitongcheng/gongyi_icon@2x.png",
        desc:"公益项目",
        flag: "gongyi",
        url: ''
      }
    ]
  },
  onLoad: function () {
    plugin.sayHello();
    var world = plugin.answer;
  },
  jumpToUrl(e) {
    var aimUrl = e.currentTarget.dataset.taskflag;
    console.log(aimUrl)

    if (aimUrl) {
      if(aimUrl === 'gongyi'){
        wx.navigateToMiniProgram({
          appId: 'wxb862c46d21e7ad95',
          path: 'pages/index/index',
          success(res) {
            // Handle success
            console.log('Successfully opened Mini Program')
          },
          fail(res) {
            // Handle failure
            console.error('Failed to open Mini Program', res)
          }
        })
      }
      if(aimUrl === 'order'){
        wx.navigateTo({
          url: "/pages/order/index"
        })
      }
    }
  },
  onShareAppMessage: function (res) {
    console.log(res);
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '收易宝银',
      path: '/page/index/index',
      success: function(res) {
        console.log(res)
      },
      fail: function(res) {
        // 转发失败
        console.log(res)
      }
    }
  },
  onShareTimeline:function(e){
    console.log(e);
  }
});

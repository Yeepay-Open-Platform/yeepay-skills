# 配置信息

| 名称 |  appId | 原始 id | 云开发环境 Id |
|----------|----------|----------|----------|
| 聚合云平台服务     |  wxb92a409f35b31843   |  gh_xx | yunkaifa-xx |

## 参考文档

<https://yeepay.feishu.cn/docx/VQcidcrpvoiaGVxJQvzcQwDinph>

## 更新配置

```bash
node script/update-config.js wxb92a409f35b31843
```

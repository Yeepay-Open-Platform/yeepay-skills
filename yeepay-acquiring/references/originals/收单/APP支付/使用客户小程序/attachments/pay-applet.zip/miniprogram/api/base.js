const RELEASE_URI = "https://qr.yeepay.com/wrap"  // 生产
const DEVELOP_URI = "https://qaqr.yeepay.com/wrap"  // qa
const TRIAL_URI = "https://qaqr.yeepay.com/wrap" // trial

module.exports = {
  RELEASE_URI,
  DEVELOP_URI,
  TRIAL_URI
}

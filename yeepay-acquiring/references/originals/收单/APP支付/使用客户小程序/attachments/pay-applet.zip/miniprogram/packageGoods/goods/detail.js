Page({
  data: {
    detail: {},
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log(options);
    if(options.item){
      this.setData({
        detail: JSON.parse(options.item)
      });
    }
  },
  tabbarIndex(){
    wx.navigateTo({
      url: '/pages/home/index',
    });
  },
  paynow(){
    wx.navigateTo({
      url: '/packageGoods/pay/payNow?amount='+this.data.detail.num,
    });
  }
});

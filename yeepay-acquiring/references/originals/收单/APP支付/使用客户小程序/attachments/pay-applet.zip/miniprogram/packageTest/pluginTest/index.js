var plugin = requirePlugin("yeepay-plugin");
const app = getApp();

Page({
  data: {
    appId: "wxbb48bac536053072",
    path: "pages/fromAppPay/index?state=4bed5c8c-d940-422c-a642-84cb770aab31&customerNo=10012426766&goodsName=%E5%86%85%E6%B5%8B%E9%AA%8C%E8%AF%81%E5%95%86%E5%93%81%E5%90%8D%E7%A7%B0&customerRequestNo=orderId67023835&orderAmount=0.03&launchSource=MINI_PROGRAM",
    params: {state:'4bed5c8c-d940-422c-a642-84cb770aab31',customArgument:'AAAA'},
    URL: "",
    items: [],
    currentItem: 0,
    pluginArgs: {}, // functional-page-navigator 调用
  },
  onLoad: function () {
    plugin.sayHello();
    var world = plugin.answer;
  },
  pay: function () {
    wx.navigateToMiniProgram({
      appId: this.data.appId,
      path: this.data.path,
    });
  },
  pluginPay: function () {
    const params = this.getUrlParams(this.data.path)
    console.log('params==',params)
    plugin.yeepayPlugin({
      fee: params.orderAmount * 100, // 显示在页面中的金额（分为单位）传1就是1分钱
      paymentArgs: params, // 任意数据，传递给功能页中的响应函数
      currencyType: 'CNY',// 需要显示在页面中的货币符号的代码，默认为 CNY
      version: 'release', //上线时, version 应改为 "release"，并确保插件所有者小程序已经发布
    }).then(res => {
      // {errMsg: "requestPluginPayment:ok", extraData: undefined}
      wx.showToast({
        title: res.errMsg,
        icon: 'none',
        duration: 3000
      })
      console.log('promise resolve===',res)
    })
    .catch(error => {
      // message 代码错误 errMsg 微信返回的错误
      // {errMsg: "requestPluginPayment:fail payment cancel"}
      console.error('promise reject===',error);
      wx.showToast({
        title: error.errMsg + error.message,
        icon: 'none',
        duration: 3000
      })
    })
  },
  appIdInput: function (e) {
    this.setData({
      appId: e.detail.value,
    });
  },
  pathInput: function (e) {
    let params = e.detail.value.split("?")[1];
    this.setData({
      path: e.detail.value,
      params:params,
      URL: "plugin://yeepay-plugin/yeepay-page?" + params,
    });
  },

  getUrlParams:function (url) {
    const params = {};
    const paramStr = url.split('?')[1];
  
    if (!paramStr) {
      return params;
    }
  
    const paramArr = paramStr.split('&');
  
    paramArr.forEach(param => {
      const [key, value] = param.split('=');
      params[key] = decodeURIComponent(value);
    });
  
    return params;
  },
  pluginPay2:function(){
    const params = this.getUrlParams(this.data.path)

    console.log('pluginPay2:57',params)
    this.setData(
      {
        pluginArgs:{
          fee: params.orderAmount * 100, // 显示在页面中的金额（分为单位）传1就是1分钱
          paymentArgs: params, // 任意数据，传递给功能页中的响应函数
          currencyType: 'CNY',// 需要显示在页面中的货币符号的代码，默认为 CNY
          version: 'release', //上线时, version 应改为 "release"，并确保插件所有者小程序已经发布
        }
      }
    )
  },

  pluginPaymentSuccess:function(e){
    console.log('pluginPayment: Success=====',e)
    wx.showToast({
      title: e.detail,
      duration: 3000
    })
  },
  pluginPaymentFail:function(e){
    console.log('pluginPayment: Fail=====',e)
    wx.showModal({
      title: '提示',
      content: JSON.stringify(e.detail),
      showCancel: false,
      success (res) {
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  pluginPaymentCancel:function(e){
    console.log('pluginPayment: Cancel=====',e)
    wx.showToast({
      title: e.detail,
      duration: 3000
    })
  }
});

const ci = require('miniprogram-ci');
const path = require('path');
const config = require('./config');
const fs = require('fs');

// 项目配置
const PROJECT_PATH = path.join(__dirname, '..');
const PRIVATE_KEY_PATH = path.join(__dirname, 'privateKeys');

// 创建项目实例
function createProject(appid) {
    const privateKeyPath = path.join(PRIVATE_KEY_PATH, `private.${appid}.key`);

    return new ci.Project({
        appid: appid,
        type: 'miniProgram',
        projectPath: PROJECT_PATH,
        privateKeyPath: privateKeyPath,
        ignores: ['node_modules/**/*']
    });
}

// 上传代码
async function uploadCode(appid, version, desc) {
    try {
        const project = createProject(appid);
        const uploadResult = await ci.upload({
            project,
            version: version,
            desc: desc,
            setting: {
                es6: true,
                minify: true,
                codeProtect: true,
                autoPrefixWXSS: true
            }
        });
        console.log('上传成功:', uploadResult);
        return uploadResult;
    } catch (error) {
        console.error('上传失败:', error);
        throw error;
    }
}

// 预览代码
async function previewCode(appid, version) {
    try {
        const project = createProject(appid);
        const previewResult = await ci.preview({
            project,
            version: version,
            setting: {
                es6: true,
                minify: true,
                codeProtect: true,
                autoPrefixWXSS: true
            },
            qrcodeFormat: 'image',
            qrcodeOutputDest: path.join(__dirname, `preview-${appid}.jpg`)
        });
        console.log('预览成功:', previewResult);
        return previewResult;
    } catch (error) {
        console.error('预览失败:', error);
        throw error;
    }
}

// 构建npm
async function buildNpm(appid) {
    try {
        const project = createProject(appid);
        const buildResult = await ci.packNpm(project);
        console.log('构建npm成功:', buildResult);
        return buildResult;
    } catch (error) {
        console.error('构建npm失败:', error);
        throw error;
    }
}

// 云开发云函数
async function deployCloudFunction(appid, name) {
    try {
        const project = createProject(appid);
        // 云开发云函数部署
        // 获取 path.join(__dirname, 'cloudfunctions'), 下的所有文件名
        const cloudfunctionsPath = path.join(__dirname, '..', 'cloudfunctions');
        const files = fs.readdirSync(cloudfunctionsPath);
        console.log('云开发云函数部署文件:', files);
        const result = [];
        files.forEach(async file => {
            const res = await ci.cloud.uploadFunction({
                project,
                env: config[appid].cloud_env,
                name: file,
                path: path.join(__dirname, '..', 'cloudfunctions', file),
                remoteNpmInstall: true, // 是否云端安装依赖
            })
            // console.log(`${file} 云开发云函数部署成功:`, res);
            result.push(res);
        })

        // console.log('云开发云函数部署成功:', result);
        return result;
    } catch (error) {
        console.error('云开发云函数部署失败:', error);
        throw error;
    }
}


// 命令行参数处理
if (require.main === module) {
    const args = process.argv.slice(2);
    const command = args[0];
    const appid = args[1];
    const version = args[2] || '1.0.0';
    const desc = args[3] || '更新说明';

    if (!appid || !config[appid]) {
        console.error('未找到appid或appid配置不存在');
        process.exit(1);
    }

    switch (command) {
        case 'upload':
            if (!version || !desc) {
                console.error('上传代码需要提供版本号和描述');
                process.exit(1);
            }
            uploadCode(appid, version, desc);
            break;
        case 'preview':
            if (!version) {
                console.error('预览需要提供版本号');
                process.exit(1);
            }
            previewCode(appid, version);
            break;
        case 'build':
            buildNpm(appid);
            break;
        case 'deployFn':
            deployCloudFunction(appid, 'fromH5Pay');
            break;
        case 'deploy':
            deployCloudFunction(appid, 'fromH5Pay');
            uploadCode(appid, version, desc);
            break;
        default:
            console.log('使用方法：');
            console.log('node ci-manager.js <command> <appid> [version] [desc]');
            console.log('命令：');
            console.log('  upload - 上传代码，需要提供版本号和描述');
            console.log('  preview - 预览代码，需要提供版本号');
            console.log('  build - 构建npm');
            console.log('示例：');
            console.log('  node ci-manager.js upload wx9610b6be9f4dd0ae 1.0.0 "更新说明"');
            console.log('  node ci-manager.js preview wx9610b6be9f4dd0ae 1.0.0');
            console.log('  node ci-manager.js build wx9610b6be9f4dd0ae');
            process.exit(0);
    }
}

module.exports = {
    uploadCode,
    previewCode,
    buildNpm,
    deployCloudFunction
};

const app = getApp()

Page({
  data: {
    appId: 'wx3ab38c026e67f023',
    path: '',
  },
  onLoad(option) {

  },
  pay: function() {
    wx.navigateToMiniProgram({
      appId: this.data.appId,
      path: this.data.path
    })
  },
  appIdInput: function (e) {
    this.setData({
      appId: e.detail.value
    })
  },
  pathInput: function (e) {
    this.setData({
      path: e.detail.value
    })
  },
})
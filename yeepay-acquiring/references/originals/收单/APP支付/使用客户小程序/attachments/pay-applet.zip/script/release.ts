import path from 'node:path'
import fs from 'fs-extra'
import c from 'picocolors'
import prompts from 'prompts'
import semver from 'semver'

const r = (p: string) => path.resolve(__dirname, p)
const prerelease = (version: string) => semver.inc(version, 'prerelease', 'beta')
const preminor = (version: string) => semver.inc(version, 'preminor', 'beta')

void (async () => {
  const result = await prompts([
    {
      type: 'multiselect',
      name: 'packageShortNames',
      message: '请选择需要更新预发布版本的包',
      choices: [
        { title: '🅰️  Ant-Design(@yeepay/antd-materials)', value: 'antd' },
        { title: '📊 Charts(@yeepay/lowcode-charts)', value: 'charts' },
        { title: '📝 Markdown(@yeepay/lowcode-markdown)', value: 'markdown' },
      ],
    },
    {
      type: 'select',
      name: 'inc',
      message: '请选择版本更新方式',
      choices: [
        { title: '🐛 Patch beta', value: prerelease },
        { title: '✨ Minor beta', value: preminor },
      ],
    },
  ])

  const { packageShortNames, inc } = result

  packageShortNames.map((name: string) => {
    const pkgUrl = r(`../packages/${name}/package.json`)
    const pkgInfo = JSON.parse(fs.readFileSync(pkgUrl, 'utf-8'))
    if (pkgInfo.version) {
      if (semver.prerelease(pkgInfo.version as string) !== null) {
        console.error(c.red(`[${name}] 已是Beta版本, 已忽略`))
        return null
      }
      pkgInfo.version = inc(pkgInfo.version as string)
      fs.writeFileSync(pkgUrl, JSON.stringify(pkgInfo, null, 2))
      console.log(c.green(`[${name}] Beta版本更新完成 ✅`))
    }
    return null
  })
})()

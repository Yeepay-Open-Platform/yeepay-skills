import { formatToFixed } from "../../utils/util";
const app = getApp();
var plugin = requirePlugin("yeepay-plugin");

Page({
  data: {
    userId: "",
    dataList: [],
    bizTypeIndex: 0,
    bizTypeArray: [
      {
        bizTypeName: "全部",
        bizType: "",
      },
      {
        bizTypeName: "已支付",
        bizType: "paid",
      },
      {
        bizTypeName: "待支付",
        bizType: "unpaid",
      },
    ],
    changeDateArrow: true,
    changeBizTypeArrow: true,
    showDate: "1",
    chooseDate: "asd",
    dateArray: [],
    appId: "",
    pageNo: 1,
    pageSize: 10,
    apiUrl: app.globalData.requestUrl,
  },
  onLoad: function (option) {
    // console.log('option==', option)
    const accountInfo = wx.getAccountInfoSync();
    if (option && option.appId) {
      // 优先取options
      this.data.appId = option.appId;
    } else if (accountInfo.miniProgram && accountInfo.miniProgram.appId) {
      this.data.appId = accountInfo.miniProgram.appId;
    } else {
    }

    plugin.sayHello();
    var world = plugin.answer;
    let now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth() + 1;
    this.setData({
      chooseDate: `${year}年${month}月`,
    });
    this.onGetOpenid();
  },
  onGetOpenid: function () {
    wx.showLoading({
      title: "加载中",
    });
    wx.cloud.init({
      traceUser: true,
    });
    // 调用云函数
    wx.cloud.callFunction({
      name: "login",
      data: {},
      success: (res) => {
        wx.hideLoading();
        this.setData({
          userId: res.result.openid,
        });
        this.fetchDate();
      },
      fail: (err) => {
        wx.hideLoading();
      },
    });
  },
  changeDateArrow: function () {
    this.setData({
      changeDateArrow: true,
    });
  },
  copyToBoard: function (e) {
    const data = e.currentTarget.dataset.value;
    wx.setClipboardData({
      data: data.merchantPhone + "",
      success: function () {
        wx.showToast({
          title: "客服号码已复制",
          icon: "none",
          duration: 2000,
        });
      },
    });
  },
  wxCall: function (e) {
    const data = e.currentTarget.dataset.value;
    wx.makePhoneCall({
      phoneNumber: data.merchantPhone + "",
      fail: function () {
        // wx.showToast({
        //   title: "拨号失败，请尝试复制号码到通讯录",
        //   icon: "none",
        //   duration: 2000,
        // });
      },
    });
  },
  // openappid
  detectAppid: function (e) {
    const data = e.currentTarget.dataset.value;
    const appId = data.merchantAppId;
    const path = data.merchantAppUrl || "";
    wx.navigateToMiniProgram({
      appId,
      path,
      // envVersion: 'trial',
      success(res) {
        console.log("跳转成功-", res);
      },
      fail(err) {
        console.log("跳转失败-", res);
      },
    });
  },

  cancelArrow: function (e) {
    this.setData({
      changeBizTypeArrow: false,
      changeDateArrow: false,
    });
  },
  changeBizTypeArrow: function (e) {
    this.setData({
      bizTypeIndex: e.detail.value,
      changeBizTypeArrow: true,
    });
  },

  fetchDate: function (pullfresh) {
    const url = this.data.apiUrl + "/getMiniOrder";
    const { appId, userId, pageNo, pageSize } = this.data;
    wx.showLoading({
      title: "加载中",
    });
    wx.request({
      url,
      method: "GET",
      header: {
        "content-type": "application/json",
      },
      data: {
        appId,
        userId,
        // userId: "oJlWw6xjBt6wOpDNx1iNbtRtAXus", // ceshi
        // userId: 'oJlWw60hGgLx4beRPiHmXCUppcig',
        pageNo,
        pageSize,
        // startTime: '2024-07-01',
        // endTime: '2024-10-17',
      },
      success: (res) => {
        wx.stopPullDownRefresh();
        wx.hideLoading();
        const code = res.data.code
        if (code === "00000" || code === "02220") {
          const list = res.data.payOrderList;
          // const count = res.data.count;
          const pageSize = res.data.pageSize;
          const pageNo = res.data.pageNo;
          // console.log("pageNo====", pageNo, "list=====", list);

          if (code === "02220") {
            wx.showToast({
              title: "退款信息暂时无法显示，请下拉页面重试",
              icon: "none",
              duration: 2000,
            });
          } else if (pullfresh == true) {
            wx.showToast({
              title: "刷新成功",
              icon: "none",
              duration: 2000,
            });
          }

          if (pageNo !== 1 && list < pageNo * pageSize) {
            this.setData({
              pageNo: this.data.pageNo - 1,
            });
            wx.showToast({
              title: "没有更多了",
              icon: "none",
              duration: 2000,
            });
            return;
          }

          // 金额补齐
          if (list.length > 0) {
            list.filter(function (item) {
              item.orderAmount = formatToFixed(item.orderAmount);
              item.refundAmount = formatToFixed(item.refundAmount);
              item.realPayAmount = formatToFixed(item.realPayAmount);
              return item;
            });
          }

          if (this.data.pageNo == 1) {
            this.setData({
              dataList: list,
            });
          } else {
            this.setData({
              dataList: this.data.dataList.concat(list),
            });
          }

        } else {
          wx.showToast({
            title: res.data.message,
            icon: "none",
            duration: 2000,
          });
        }
      },
      fail: (err) => {
        wx.stopPullDownRefresh();
        wx.hideLoading();
        wx.showToast({
          title: JSON.stringify(err),
          icon: "none",
          duration: 2000,
        });
      },
    });
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    // pagenum=1,request
    this.setData({
      pageNo: 1,
    });
    this.fetchDate(true);
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onReachBottom() {
    // pagenum++,request
    this.setData({
      pageNo: this.data.pageNo + 1,
    });
    console.log("上拉了");
    this.fetchDate();
  },
});

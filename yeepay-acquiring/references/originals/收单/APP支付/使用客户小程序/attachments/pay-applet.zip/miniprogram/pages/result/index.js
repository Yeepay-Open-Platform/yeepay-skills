const app = getApp()

Page({
  data: {
    orderAmount: '',
    payResult: '',
    scene: 0,
    customerRequestNo:'',
    hideSuccessPopup: false
  },
  onLoad(option) {
    this.setData({
      scene: option.scene,
      orderAmount: option.orderAmount,
      payResult: option.payResult,
      customerRequestNo: option.customerRequestNo,
		})
  },
  onShow(){
    console.log('show')
  },
  onHide(){
    console.log('onHide', this.data.scene)
    this.setData({
      hideSuccessPopup: true
		})
  },
  goBack: function() {
    console.log({'status':this.data.payResult})
    let status = this.data.payResult === 'payError' ? 'fail' : 'success'
    let message = this.data.payResult === 'payError' ? '支付失败' : '支付成功'
    let customerRequestNo = this.data.customerRequestNo
    wx.navigateBackMiniProgram({
      extraData: {
        status: status,
        message: message,
        customerRequestNo
      }
    });
  },
  exitProgram: function () {
    wx.exitMiniProgram();
  },
})

const app = getApp();
Page({
  data: {
    navigationSetting: {
      title: '付款',
      navBarHeight: app.globalData.navBarHeight,
      statusBarHeight: app.globalData.statusBarHeight,
      showBack: true,
    },
    height: app.globalData.navBarHeight + app.globalData.statusBarHeight,
  },

});

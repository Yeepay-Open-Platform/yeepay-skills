const app = getApp();
Page({
  data: {
    navigationSetting: {
      title: '收银台',
      navBarHeight: app.globalData.navBarHeight,
      statusBarHeight: app.globalData.statusBarHeight,
      showBack: true,
    },
    height: app.globalData.navBarHeight + app.globalData.statusBarHeight,
    amount: 0
  },
  onLoad(options){
    console.log(options)
    this.setData({
      amount: options.amount + '.00'
    })
  }
});

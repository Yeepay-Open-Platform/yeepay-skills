// pages/index.js
const app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    navigationSetting: {
      title: "建站服务",
      navBarHeight: app.globalData.navBarHeight,
      statusBarHeight: app.globalData.statusBarHeight,
      showBack: true,
    },
    height: app.globalData.navBarHeight + app.globalData.statusBarHeight,
    list: [
      {
        id: 1,
        title: "C/S架构软件开发",
        desc: "C/S 即客户机和服务器结构，它是软件系统体系结构，通过它可以充分利用两端硬件环境的优势，将任务合理分配到 Client 端和 Server 端来实现，降低了系统的通讯反复。目前多数应用软件系统都是 Client/Server 形式的两层结构，由于现在的软件应用系统正在向分布式的 Web 应用发展，Web 和 Client/Server 应用都可以进行同样的业务处理，应用不同的模块共享逻辑组件，所以内部的和外部的用户都可以访问新的和现有的应用系统，通过现有应用系统中的逻辑可以扩展出新的应用系统。这也就是目前应用系统的发展方向。",
        banner: "https://img.yeepay.com/fe-resources/mini-app/img/cs@2x.png",
      },
      {
        id: 2,
        title: "B/S架构软件开发",
        desc: "B/S 结构即浏览器和服务器结构，算是对 C/S 结构的一种改进，在这种结构下，用户工作界面是通过浏览器来实现，极少部分事务逻辑在前端，主要在服务器端实现，这样就大大缩减终端压力，减轻了系统维护与升级的成本和工作量，降低了成本，以目前的技术看 B/S 架构管理软件更方快捷、高效。",
        banner: "https://img.yeepay.com/fe-resources/mini-app/img/BS@2x.png",
      },
      {
        id: 3,
        title: "手机APP开发",
        desc: "通常人们所说的APP大多可以理解成手机中的应用软件，目前手机应用多种多样，大多为通信类，购物类，游戏类，支付类，办公类，打车类也正是这些应用极大的丰富了人们的日常生活，使得人们对手机的需求与日俱增，使用时长和频率也大大增加，可见移动应用对人们来说是多么重要。",
        banner: "https://img.yeepay.com/fe-resources/mini-app/img/APP@2x.png",
      },
      {
        id: 4,
        title: "软件升级",
        desc: "一款软件投放到市场经过运营会发现一些问题，有些问题是程序本身的漏洞，有些则是开发者对市场调研不足功能设计偏离实际需求，无论那种情况都要及时处理，让软件使用流畅功能更受用户喜欢。",
        banner: "https://img.yeepay.com/fe-resources/mini-app/img/shengji.png",
      },
    ],
    activeId: 1,
    activeInfo: {},
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let { id } = options;
    id = id ? parseInt(id) : 1;
    let activeInfo = this.data.list.find((item) => item.id == id) || {};
    this.setData({
      activeInfo: activeInfo,
      navigationSetting: {
        ...this.data.navigationSetting,
        title: activeInfo.title,
      },
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {},
});
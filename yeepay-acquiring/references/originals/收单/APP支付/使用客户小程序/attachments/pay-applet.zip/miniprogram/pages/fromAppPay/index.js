import Toast from '../../components/@vant/toast/toast';
import tool from "../../utils/util.js";
const app = getApp();
Page({
  data: {
    payResult: "nomal",
    loading: false,
    disabled: false,
    showSuccessPopup: false,
    uniqueOrderNo: "",
    scene: 0,
    qaList: [
      "10040020578",
      "10040040287",
      "10080020652",
      "10028240235",
      "10080029837",
    ],
    orderInfo: {
      state: "",
      customerNo: "", // 商户编号
      customerRequestNo: "", // 商户交易订单号
      orderAmount: "", // 订单金额
      goodsName: "", // 商品名称(传参过来，不支持中文)
      authCode: "",
    },
    launchSourceMap: {
      MINI_PROGRAM: 1037,
      SDK_PAY: 1069,
    },
    requestPamentTask: null,
    paymentLoading: "",
    realtimeLogger: null,
    launchType: "FULL_SCREEN",
    loadingToast: null,
    merchantAppId: null
  },
  onLoad(option) {
    
    const referrerInfo =  app.globalData.referrerInfo
    if (referrerInfo && option.launchSource === 'MINI_PROGRAM') {
      if(referrerInfo.appId) {
        this.data.merchantAppId = referrerInfo.appId
      } else {
        console.log("未获取到小程序id")
      }
    }

    this.data.loadingToast = Toast.loading({
      mask:true,
      message: '加载中...',
      forbidClick: true,
      duration: 0
    });
    this.setData({
      loading: true,
      disabled: true,
    });
    if (wx.canIUse("getRealtimeLogManager")) {
      const logger = wx.getRealtimeLogManager();
      this.setData({
        realtimeLogger: logger,
      });

      this.data.realtimeLogger.info("fromAppPay: 页面 初始化 ===", option);
    }
    let launchType = wx.getLaunchOptionsSync().apiCategory;
    if (wx.canIUse("getEnterOptionsSync")) {
      launchType = wx.getEnterOptionsSync().apiCategory;
    }
    const scene = option.launchSource
      ? this.data.launchSourceMap[option.launchSource]
      : wx.getLaunchOptionsSync().scene;

    this.data.realtimeLogger &&
      this.data.realtimeLogger.info(
        "fromAppPay: 场景值： ===",
        scene,
        launchType
      );
    console.log(scene, launchType);
    // 设置跳转携带的参数
    this.setData({
      scene,
      launchType: launchType === "embedded" ? "HALF_SCREEN" : "FULL_SCREEN",
      orderInfo: {
        state: option.state,
        customerNo: option.customerNo,
        customerRequestNo: option.customerRequestNo,
        orderAmount: Number(option.orderAmount).toFixed(2),
        goodsName: decodeURIComponent(option.goodsName),
        authCode: "",
      },
      loading: true,
      disabled: true,
    });
    if (this.data.paymentLoading !== "pedding") {
      this.login();
    } else {
      wx.showToast({
        title: "有未支付完成的订单...",
        icon: "none",
        duration: 3000,
      });
    }
  },
  login: tool.debounce(function () {
    this.setData({
      loading: true,
      disabled: true,
    });
    this.data.realtimeLogger &&
      this.data.realtimeLogger.info("fromAppPay[login]: 登录 ===");
    wx.login({
      success: (res) => {
        if (res.code) {
          this.data.orderInfo.authCode = res.code;
          this.confirmPay();
        } else {
          this.data.realtimeLogger &&
            this.data.realtimeLogger.warn(
              this.data.orderInfo.state + "warn log ===",
              res.errMsg
            );
          wx.showToast({
            title: `登录失败！${res.errMsg}`,
            icon: "none",
            duration: 3000,
          });
        }
      },
      fail: (err) => {
        this.data.realtimeLogger &&
          this.data.realtimeLogger.error("wx.login fail ===", err);
      },
      complete: (res) => {},
    });
  }),
  confirmPay: tool.debounce(function () {
    this.data.loadingToast = Toast.loading({
      mask:true,
      message: '加载中...',
      forbidClick: true,
      duration: 0
    });
    this.data.realtimeLogger &&
      this.data.realtimeLogger.info(
        "fromAppPay[confirmPay]:  start 调用 API: /qr/wrap/pay  ==="
      );
    let url = "https://qr.yeepay.com/wrap/pay";
    if (this.data.qaList.includes(this.data.orderInfo.customerNo)) {
      url = "https://aggwrapqa.yeepay.com/aggregation-pay-server/qr/wrap/pay";
    }
    wx.request({
      url,
      method: "POST",
      header: {
        "content-type": "application/json",
      },
      data: {
        state: this.data.orderInfo.state,
        authCode: this.data.orderInfo.authCode,
        launchType: this.data.launchType,
        merchantAppId: this.data.merchantAppId
      },
      success: async (res) => {
        if (res.data.code == "00000") {
          this.data.uniqueOrderNo = res.data.uniqueOrderNo;
          this.data.realtimeLogger &&
            this.data.realtimeLogger.info(
              "fromAppPay[confirmPay]:  获取订单信息成功  ===",
              res.data
            );
          await this.requestPayment(JSON.parse(res.data.prePayTn));
        } else {
          this.data.realtimeLogger &&
            this.data.realtimeLogger.warn(
              "wx.request confirmPay warn log ===",
              `${res.data.message}(${this.data.orderInfo.state})`
            );
          wx.showToast({
            title: `${res.data.message}(${this.data.orderInfo.state})`,
            icon: "none",
            duration: 3000,
          });
        }
      },
      fail: (err) => {
        this.data.realtimeLogger &&
          this.data.realtimeLogger.error(
            `wx.request confirmPay fail (${this.data.orderInfo.state}) ===`,
            err
          );
        wx.showToast({
          title: JSON.stringify(err),
          icon: "none",
          duration: 5000,
        });
      },
      complete: () => {
        this.data.loadingToast.clear()
        this.setData({
          loading: false,
          disabled: false,
        });
      },
    });
  }),
  requestPayment: function (data) {
    this.data.realtimeLogger &&
      this.data.realtimeLogger.info(
        `fromAppPay[requestPayment]:  start 唤起支付 ===`
      );
    this.setData({
      paymentLoading: "pedding",
    });
    wx.requestPayment({
      ...data,
      success: (res) => {
        console.log('支付成功',res)
        this.data.realtimeLogger &&
          this.data.realtimeLogger.info(
            `fromAppPay[requestPayment]:  支付成功 ===`,
            res
          );
          let orderAmount = this.data.orderInfo.orderAmount
          let scene = this.data.scene
          let customerRequestNo = this.data.orderInfo.customerRequestNo
          setTimeout(function(){
            wx.reLaunch({
              url: `/pages/result/index?payResult=success&orderAmount=${orderAmount}&scene=${scene}&customerRequestNo=${customerRequestNo}`,
              success(res){
                console.log('reLaunch 成功', res)
              },
              fail(err){
                console.log('reLaunch 失败', err)
              }
            })
          },200)
      },
      fail: (err) => {
        console.log('支付失败',err)
        this.data.realtimeLogger &&
          this.data.realtimeLogger.error(
            `fromAppPay[requestPayment]: 支付失败 ===`,
            err
          );
        this.setData({
          payResult: "payError",
        });
      },
      complete: () => {
        this.setData({
          loading: false,
          disabled: false,
          paymentLoading: "resolved",
        });
      },
    });
  },
  goBack: function () {
    this.data.realtimeLogger &&
      this.data.realtimeLogger.info(
        `fromAppPay[goBack]:  取消支付/返回商家 scene(${this.data.scene})===`
      );
    wx.navigateBackMiniProgram({
      extraData: {
        status: 'cancel',
        message: '用户取消支付',
        customerRequestNo: this.data.orderInfo.customerRequestNo
      }
    });
  },
  hideSuccessPopup: function () {
    this.data.realtimeLogger &&
      this.data.realtimeLogger.info(
        `fromAppPay[hideSuccessPopup]:  退出程序 ===`
      );
    this.setData({
      showSuccessPopup: false,
    });
    wx.exitMiniProgram();
  },
});

const app = getApp();

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    defaultSetting: {
      type: Object,
      value: {
        title: "默认标题",
        backgroundColor: "#fff",
        navBarHeight: 40,
        statusBarHeight: 47,
        showBack: true,
      },
    },
  },

  /**
   * 组件的初始数据
   */
  data: {
    height: app.globalData.navBarHeight + app.globalData.statusBarHeight,
  },
  lifetimes: {},
  methods: {
    bindCallBack() {
      wx.navigateBack({
        delta: 1,
      });
    },
  },
  options: {
    styleIsolation: "apply-shared", // 在组件定义时的选项中启用多slot支持
  },
});

# 接入指南

# 小程序添加插件

请在 「小程序后台 - 设置 - 第三方设置 - 插件管理 中搜索 【聚合云服务端】并添加插件。

app.json中加入如下配置
```
"plugins": {
  "yeepay-plugin": {
    "version": "latest",
    "provider": "wx967b76d97aa5b662"
  }
}
```

# 支付插件使用
## 调用聚合托管下单进行预下单
接口响应参数如下：

| 参数名          | 类型      | 必填 | 描述          | 备注               |
| -------------- | -------- | ---- | ------------ | ------------------ |
| code           | string   | 是   | 00000        |                    |
| message        | string   | 是   | -            |                    |
| uniqueOrderNo  | string   | 否   | 唯一流水号     | 成功时必返          |
| prePayTn       | JSON     | 否   | 返回参数      |                    |
| appId          | string   | 否   | 小程序appId   |                    |
| miniProgramPath| string   | 否   | 跳转小程序的路径 |                   |
| miniProgramOrgId| string  | 否   | 小程序原始id | 转成md格式         |

```

## 小程序调用
const plugin = requirePlugin('yeepay-plugin')
Page({
  ...,
  getUrlParams(prePayTn){
    const params = {};
    const paramStr = prePayTn.split('?')[1];
    if (!paramStr) {
      return params;
    }
    const paramArr = paramStr.split('&');
    paramArr.forEach(param => {
      const [key, value] = param.split('=');
      params[key] = decodeURIComponent(value);
    });
    return params;
  },
  // 调用插件支付
  handlePluginPay() {
    // 预下单接口返回的参数 prePayTn  格式化为对象
    const params = this.getUrlParams(prePayTn)
    plugin.yeepayPlugin({
      fee: params.orderAmount * 100, // 显示在页面中的金额（分为单位）传1就是1分钱
      paymentArgs: params, // 任意数据，传递给功能页中的响应函数
      currencyType: 'CNY',// 需要显示在页面中的货币符号的代码，默认为 CNY
      version: 'release', //上线时, version 应改为 "release"，并确保插件所有者小程序已经发布
    }).then(res => {
      // {errMsg: "requestPluginPayment:ok", extraData: undefined}
      wx.showToast({
        title: res.errMsg,
        icon: 'none',
        duration: 3000
      })
      console.log('promise resolve===',res)
    })
    .catch(error => {
      // message 代码错误 errMsg 微信返回的错误
      // {errMsg: "requestPluginPayment:fail payment cancel"}
      console.error('promise reject===',error);
      wx.showToast({
        title: error.errMsg + error.message,
        icon: 'none',
        duration: 3000
      })
    })
  },
});

```

```js
if (options.scene == '1038' && options.referrerInfo.appId=='xxxx') {
  // 代表从收银台小程序返回
  let extraData = options.referrerInfo.extraData;
  console.log('extraData',extraData)
  if (!extraData) {
    // "当前通过物理按键返回，未收接到返参，建议自行查询交易结果";
  }
}

```

## 注意事项

1. 基础库版本 > 2.22.1
2. 主体为个人小程序在使用插件时，都无法正常使用插件里的支付功能。
3. 请使用【预览】或者【真机调试】来测试 （如果调起来过一次，后面调不起来了，请预览和真机调试换着用）

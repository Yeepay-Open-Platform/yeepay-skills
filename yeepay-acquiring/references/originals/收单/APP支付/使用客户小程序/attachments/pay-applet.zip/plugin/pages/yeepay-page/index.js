// plugin/pages/yeepay-page.js
Page({
  data: {
    payResult: "nomal",
    loading: false,
    disabled: false,
    showSuccessPopup: false,
    uniqueOrderNo: "",
    scene: 0,
    qaList: [
      "10040020578",
      "10040040287",
      "10080020652",
      "10028240235",
      "10080029837",
    ],
    orderInfo: {
      state: "",
      customerNo: "", // 商户编号
      customerRequestNo: "", // 商户交易订单号
      orderAmount: "", // 订单金额
      goodsName: "", // 商品名称(传参过来，不支持中文)
      authCode: "",
    },
    launchSourceMap: {
      MINI_PROGRAM: 1037,
      SDK_PAY: 1069,
    },
  },

  onLoad(option) {
    console.log("option=======", option);
    // wx.hideShareMenu({})
    // const scene = option.launchSource
    //   ? this.data.launchSourceMap[option.launchSource]
    //   : wx.getLaunchOptionsSync().scene;
    // // 设置跳转携带的参数
    // this.setData({
    //   scene,
    //   orderInfo: {
    //     state: option.state,
    //     customerNo: option.customerNo,
    //     customerRequestNo: option.customerRequestNo,
    //     orderAmount: option.orderAmount,
    //     goodsName: decodeURIComponent(option.goodsName),
    //     authCode: "",
    //   },
    // });
    // this.login();
  },
  login: function () {
    wx.pluginLogin({
      success: (res) => {
        if (res.code) {
          this.data.orderInfo.authCode = res.code;
          console.log("res.code", res.code);
          this.confirmPay();
        } else {
          wx.showToast({
            title: `登录失败！${res.errMsg}`,
            icon: "none",
            duration: 3000,
          });
        }
      },
      fail: (res) => {},
      complete: (res) => {},
    });
  },

  confirmPay: function () {
    this.setData({
      loading: true,
      disabled: true,
    });
    let url = "https://qr.yeepay.com/wrap/plugin-pay";
    if (this.data.qaList.includes(this.data.orderInfo.customerNo)) {
      url =
        "https://aggwrapqa.yeepay.com/aggregation-pay-server/qr/wrap/plugin-pay";
    }
    wx.request({
      url,
      method: "POST",
      header: {
        "content-type": "application/json",
      },
      data: {
        state: this.data.orderInfo.state,
        authCode: this.data.orderInfo.authCode,
      },
      success: (res) => {
        console.log('success =====',res )
        if (res.data.code == "00000") {
          this.data.uniqueOrderNo = res.data.uniqueOrderNo;
          console.log("res.data.prePayTn", res.data.prePayTn);
          this.requestPayment(JSON.parse(res.data.prePayTn));
        } else {
          wx.showToast({
            title: `${res.data.message}(${this.data.orderInfo.state})`,
            icon: "none",
            duration: 3000,
          });
        }
      },
      fail: (err) => {
        console.log('fail',err )
        wx.showToast({
          title: JSON.stringify(err),
          icon: "none",
          duration: 5000,
        });
      },
      complete: () => {
        this.setData({
          loading: false,
          disabled: false,
        });
      },
    });
  },
  requestPayment: function (data) {
    // wx.requestPluginPayment({
    //   version: 'release',
    //   fee: 1,
    //   paymentArgs: {},
    //   currencyType: 'CNY',
    //   success (res) { },
    //   fail (res) { }
    // })
    console.log('data===',data);
    wx.requestPluginPayment({
      ...data,
      success: () => {
        this.setData({
          showSuccessPopup: true,
        });
      },
      fail: (res) => {
        this.setData({
          payResult: "payError",
        });
      },
    });
  },
  goBack: function () {
    wx.navigateBackMiniProgram();
  },
  hideSuccessPopup: function () {
    this.setData({
      showSuccessPopup: false,
    });
    wx.exitMiniProgram();
  },
});

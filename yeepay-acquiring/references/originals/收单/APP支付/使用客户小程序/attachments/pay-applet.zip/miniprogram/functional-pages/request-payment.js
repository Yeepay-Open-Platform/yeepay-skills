// functional-pages/request-payment.js
const app = getApp()

exports.beforeRequestPayment = function (paymentArgs, callback) {
  // 注意：
  // 功能页函数（这个函数）不应 require 其他非 functional-pages 目录中的文件，
  // 其他非 functional-pages 目录中的文件也不应 require 这个目录中的文件，
  // 这样的 require 调用在未来将不被支持。
  //
  // 同在 functional-pages 中的文件可以 require
  // var getOpenIdURL ="https://aggwrapqa.yeepay.com/aggregation-pay-server/qr/wrap/pay"
  // require("./request-payment").getOpenIdURL;
  let logger = null
  if (wx.getRealtimeLogManager) {
    const logManager = wx.getRealtimeLogManager()
    logger = logManager.tag(paymentArgs.state)
  }

  logger && logger.info('插件入参:', paymentArgs)
  var qaList = [
    "10040020578",
    "10040040287",
    "10080020652",
    "10028240235",
    "10080029837",
  ];
  var getOpenIdURL = "https://qr.yeepay.com/wrap/pay";

  if (qaList.includes(paymentArgs.customerNo)) {
    getOpenIdURL =
      "https://aggwrapqa.yeepay.com/aggregation-pay-server/qr/wrap/pay";
  }

  // 自定义的参数，此处应为从插件传递过来的
  console.log('request-payment===',paymentArgs)
  console.log('callback===',callback)

  const merchantAppId = app.globalData.referrerInfo.appId || null

  // if (!merchantAppId) {
  //   wx.showToast({
  //     title: "未获取到小程序id",
  //     icon: "none",
  //     duration: 2000
  //   });
  // }

  // 第一步：调用 wx.login 方法获取 code，然后在服务端调用微信接口使用 code 换取下单用户的 openId
  // 具体文档参考 https://mp.weixin.qq.com/debug/wxadoc/dev/api/api-login.html?t=20161230#wxloginobject
  wx.login({
    success: function (data) {
      console.log('WXlogin:', data)
      wx.request({
        url: getOpenIdURL,
        method: "POST",
        header: {
          "content-type": "application/json",
        },
        data: {
          state: paymentArgs.state,
          authCode: data.code,
          launchType: 'PLUGIN',
          merchantAppId,
        },
        success: function (res) {
          logger && logger.info('获取 prePayTn 成功:', res.data)
          if (res.data.code == "00000") {
            let uniqueOrderNo = res.data.uniqueOrderNo;
            let requestPaymentArgs = JSON.parse(res.data.prePayTn);
            // 在 callback 中需要返回两个参数： err 和 requestPaymentArgs：
            // err 应为 null （或者一些失败信息）；
            // requestPaymentArgs 将被用于调用 wx.requestPayment，除了 success/fail/complete 不被支持外，
            // 应与 wx.requestPayment 参数相同。
            requestPaymentArgs.extraData = { // 用 extraData 传递自定义数据，该字段将被无修改地透传到支付成功的回调参数中
              status: 'success',
              message: '支付成功',
              customerRequestNo: paymentArgs.customerRequestNo || '',
              uniqueOrderNo: uniqueOrderNo
            }
            var error = null;
            callback(error, requestPaymentArgs);
          } else {
            console.log("order fail:", res);
            logger && logger.warn('获取 prePayTn 失败:', res)
            // wx.showToast({
            //   title: res.data.message + "[" + paymentArgs.state + "]",
            //   icon: "none",
            //   duration: 3000,
            // });
            callback(res.data);
          }
        },
        fail: function (error) {
          logger && logger.error('下单接口请求失败:', error)
          console.log("request-payment ====:", error);
          // callback 第一个参数为错误信息，返回错误信息
          callback(error);
        },
      });
    },
    fail: function (err) {
      logger && logger.error('wx.login 接口调用失败:', err)
      console.log("wx.login 接口调用失败，将无法正常使用开放接口等服务", err);
      // callback 第一个参数为错误信息，返回错误信息
      callback(err);
    },
  });
};

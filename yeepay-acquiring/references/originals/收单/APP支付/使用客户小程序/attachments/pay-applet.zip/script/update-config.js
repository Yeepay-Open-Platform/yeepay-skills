const fs = require('fs');
const path = require('path');
const config = require('./config');

// 配置文件路径
const PROJECT_CONFIG_PATH = path.join(__dirname, '../project.config.json');
const APP_JSON_PATH = path.join(__dirname, '../miniprogram/app.json');
const CLOUD_STATIC_H5_TPL_PATH = path.join(__dirname, '../html/tpl.html');
const CLOUD_STATIC_H5_PATH = path.join(__dirname, '../html/jump-mp-v1.html');

// 读取配置文件
function readConfig(filePath) {
    try {
        const configContent = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(configContent);
    } catch (error) {
        console.error(`读取配置文件失败: ${filePath}`, error);
        process.exit(1);
    }
}

// 写入配置文件
function writeConfig(filePath, config) {
    try {
        fs.writeFileSync(filePath, JSON.stringify(config, null, 2), 'utf8');
        console.log(`配置文件更新成功: ${filePath}`);
    } catch (error) {
        console.error(`写入配置文件失败: ${filePath}`, error);
        process.exit(1);
    }
}

// 更新所有配置
function updateAllConfigs(appid) {
    // 检查appid是否存在
    if (!config[appid]) {
        console.error(`未找到appid: ${appid} 的配置信息`);
        process.exit(1);
    }

    const appConfig = config[appid];

    // 1. 更新 project.config.json
    const projectConfig = readConfig(PROJECT_CONFIG_PATH);
    projectConfig.appid = appid;
    projectConfig.projectname = appConfig.app_name;
    projectConfig.pluginAppid = appid;
    writeConfig(PROJECT_CONFIG_PATH, projectConfig);

    // 2. 更新 app.json
    const appJson = readConfig(APP_JSON_PATH);
    appJson.window.navigationBarTitleText = appConfig.app_name;
    writeConfig(APP_JSON_PATH, appJson);

    // 更新云开发静态 H5
    updateCloudStaticH5(appConfig);

    console.log('所有配置更新完成！');
    console.log('更新信息：');
    console.log(`- AppID: ${appid}`);
    console.log(`- 项目名称: ${appConfig.app_name}`);
    console.log(`- 导航栏标题: ${appConfig.app_name}`);
    console.log(`- 原始 ID: ${appConfig.original_id}`);
    console.log(`- 云开发环境 ID: ${appConfig.cloud_env}`);
}

// 更新云开发静态 H5
function updateCloudStaticH5(appConfig) {
    // 读取文件内容，替换appid、原始 id、 云开发环境 ID
    let cloudStaticH5Content = fs.readFileSync(CLOUD_STATIC_H5_TPL_PATH, 'utf8');
    let newCloudStaticH5Content = cloudStaticH5Content
        .replace(/<%= appid %>/g, `${appConfig.appid}`)
        .replace(/<%= username %>/g, `${appConfig.original_id}`)
        .replace(/<%= resourceEnv %>/g, `${appConfig.cloud_env}`);
    fs.writeFileSync(CLOUD_STATIC_H5_PATH, newCloudStaticH5Content, 'utf8');
}

// 命令行参数处理
if (require.main === module) {
    const args = process.argv.slice(2);

    if (args.length === 0) {
        console.log('使用方法：');
        console.log('node update-config.js <appid>');
        console.log('示例：');
        console.log('node update-config.js wx9610b6be9f4dd0ae');
        process.exit(0);
    }

    const appid = args[0];
    updateAllConfigs(appid);
}

module.exports = {
  updateAllConfigs,
  updateCloudStaticH5
};
